import React, { useState, useMemo, useRef } from 'react';
import { 
  Upload, 
  Activity, 
  Zap, 
  BarChart3, 
  Database, 
  CheckCircle2,
  Play,
  FileText,
  Brain,
  Timer,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Papa from 'papaparse';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  ScatterChart, 
  Scatter, 
  ZAxis, 
  BarChart, 
  Bar, 
  Cell,
  AreaChart,
  Area,
  Legend
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { calculatePearsonR, calculateTTest, round, getInterpretation } from './lib/stats';

/**
 * Utility for Tailwind classes
 */
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Types for the EEG data
interface TrialData {
  trial_id: string | number;
  block: number;
  stimulus_letter: string;
  key_pressed: string;
  correct: number;
  reaction_time_ms: number;
  beta_power_db: number;
  alpha_power_db: number;
  theta_power_db: number;
  trial_onset_s: number;
  participant: string;
}

interface AnalysisResults {
  correlation: { r: number; p: number; n: number };
  ttest: { t: number; p: number; mean1: number; mean2: number };
  fatigue: { block: number; beta: number }[];
}

type PipelineStep = 'Epoch' | 'Clean' | 'FFT' | 'Analyze' | 'Visualize';

export default function App() {
  const [data, setData] = useState<TrialData[]>([]);
  const [analyzed, setAnalyzed] = useState<boolean>(false);
  const [activeStep, setActiveStep] = useState<PipelineStep | null>(null);
  const [results, setResults] = useState<AnalysisResults | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Summary statistics computed on data load
  const summary = useMemo(() => {
    if (data.length === 0) return null;
    const accuracy = (data.filter(t => t.correct === 1).length / data.length) * 100;
    const validRTs = data.filter(t => t.reaction_time_ms !== null && !isNaN(t.reaction_time_ms));
    const meanRT = validRTs.reduce((acc, t) => acc + t.reaction_time_ms, 0) / (validRTs.length || 1);
    const meanBeta = data.reduce((acc, t) => acc + (t.beta_power_db || 0), 0) / data.length;
    return { count: data.length, accuracy, meanRT, meanBeta };
  }, [data]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      complete: (results) => {
        const parsed = results.data as TrialData[];
        setData(parsed);
        setAnalyzed(false);
        setResults(null);
        setActiveStep('Epoch');
        
        // Simulate fast pipeline progress
        setTimeout(() => setActiveStep('Clean'), 150);
        setTimeout(() => setActiveStep('FFT'), 300);
        setTimeout(() => setActiveStep(null), 450);
      },
      error: (error) => {
        console.error('CSV Parsing Error:', error);
      }
    });
  };

  const runAnalysis = () => {
    if (data.length === 0) return;
    
    setActiveStep('Analyze');
    
    // Pearson Beta-RT
    const validRT = data.filter(t => t.reaction_time_ms !== null && !isNaN(t.reaction_time_ms));
    const corr = calculatePearsonR(
      validRT.map(t => t.beta_power_db),
      validRT.map(t => t.reaction_time_ms)
    );

    // T-test Correct vs Missed
    const correctBeta = data.filter(t => t.correct === 1).map(t => t.beta_power_db);
    const missedBeta = data.filter(t => t.correct === 0).map(t => t.beta_power_db);
    const ttest = calculateTTest(correctBeta, missedBeta);

    // Fatigue trend
    const uniqueBlocks: number[] = Array.from(new Set(data.map(t => Number(t.block))));
    const blocks = uniqueBlocks.sort((a, b) => a - b);
    const fatigue = blocks.map(b => {
      const blockTrials = data.filter(t => t.block === b);
      return {
        block: b,
        beta: blockTrials.reduce((acc, t) => acc + (t.beta_power_db || 0), 0) / (blockTrials.length || 1)
      };
    });

    setResults({
      correlation: corr,
      ttest: ttest,
      fatigue: fatigue,
    });

    setTimeout(() => {
      setAnalyzed(true);
      setActiveStep('Visualize');
    }, 200);
  };

  // --- Visuals: Data Generation (Simulated as per Python Script) ---
  
  const histogramData = useMemo(() => {
    if (data.length === 0) return [];
    const powers = data.map(d => d.beta_power_db).filter(p => typeof p === 'number' && !isNaN(p));
    if (powers.length === 0) return [];
    
    const minVal = Math.floor(Math.min(...powers));
    const maxVal = Math.ceil(Math.max(...powers));
    const binCount = 15;
    const range = maxVal - minVal;
    const step = range === 0 ? 1 : range / binCount;
    
    const bins = Array.from({ length: binCount }, (_, i) => ({
      bin: String(round(minVal + i * step, 1)),
      count: 0
    }));

    data.forEach(d => {
      if (typeof d.beta_power_db !== 'number' || isNaN(d.beta_power_db)) return;
      const idx = Math.min(Math.floor((d.beta_power_db - minVal) / step), binCount - 1);
      if (idx >= 0) bins[idx].count++;
    });

    return bins;
  }, [data]);

  const psdData = useMemo(() => {
    const freqs = Array.from({ length: 100 }, (_, i) => i * 0.5 + 1);
    return freqs.map(f => {
      let base = 40 / Math.pow(f, 1.2) + (Math.random() - 0.5) * 0.5;
      if (Math.abs(f - 10) < 1) base += 8; // Alpha peak
      if (Math.abs(f - 20) < 1.5) base += 4; // Beta peak
      const psd_db = 10 * Math.log10(Math.max(base, 0.1));
      return { freq: f, psd: psd_db };
    });
  }, []);

  const loadSampleData = () => {
    setActiveStep('Epoch');
    const sample: TrialData[] = Array.from({ length: 48 }, (_, i) => {
      const isCorrect = Math.random() > 0.15 ? 1 : 0;
      const beta = -10 - Math.random() * 5 + (isCorrect ? 2 : 0);
      return {
        trial_id: i + 1,
        block: Math.floor(i / 12) + 1,
        stimulus_letter: ['A', 'B', 'C', 'D'][Math.floor(Math.random() * 4)],
        key_pressed: 'X',
        correct: isCorrect,
        reaction_time_ms: 350 + Math.random() * 200 - (beta * 5),
        beta_power_db: beta,
        alpha_power_db: -15 + Math.random() * 3,
        theta_power_db: -5 + Math.random() * 2,
        trial_onset_s: i * 2.5,
        participant: 'SUB_001_DEMO'
      };
    });

    setTimeout(() => {
      setData(sample);
      setAnalyzed(false);
      setActiveStep('Clean');
      setTimeout(() => setActiveStep('FFT'), 150);
      setTimeout(() => setActiveStep(null), 300);
    }, 100);
  };

  const erpData = useMemo(() => {
    const times = Array.from({ length: 100 }, (_, i) => i * 7 - 200);
    return times.map(t => {
      const erp_correct = -2 * Math.exp(-Math.pow(t - 180, 2) / (2 * Math.pow(35, 2))) 
                          - 5 * Math.exp(-Math.pow(t - 280, 2) / (2 * Math.pow(50, 2)))
                          + (Math.random() - 0.5) * 0.3;
      const erp_missed = -1 * Math.exp(-Math.pow(t - 200, 2) / (2 * Math.pow(40, 2))) 
                         - 2 * Math.exp(-Math.pow(t - 310, 2) / (2 * Math.pow(60, 2)))
                         + (Math.random() - 0.5) * 0.3;
      return { time: t, correct: erp_correct, missed: erp_missed };
    });
  }, []);

  return (
    <div className="min-h-screen bg-bg text-text font-sans selection:bg-accent/30">
      <aside className="fixed left-0 top-0 bottom-0 w-[220px] bg-bg border-r border-border p-6 hidden lg:flex flex-col">
        <div className="mb-10">
          <div className="flex items-center gap-2 mb-1">
            <Brain className="w-5 h-5 text-accent" />
            <h1 className="text-xs font-bold uppercase tracking-widest text-accent">NeuroPipe v2.4</h1>
          </div>
          <p className="text-[10px] text-text-dim font-mono uppercase">EEG Analysis Suite</p>
        </div>

        <nav className="flex-1">
          <div className="text-[10px] font-bold text-gray-600 uppercase tracking-widest mb-6">Pipeline Monitor</div>
          <div className="space-y-4">
            {[
              { id: 'Epoch', label: '01 Epoch', icon: Timer },
              { id: 'Clean', label: '02 Clean', icon: Zap },
              { id: 'FFT', label: '03 FFT', icon: BarChart3 },
              { id: 'Analyze', label: '04 Analyze', icon: Activity },
              { id: 'Visualize', label: '05 Visualize', icon: Database },
            ].map((step, idx) => {
              const isCompleted = activeStep && ['Epoch', 'Clean', 'FFT', 'Analyze', 'Visualize'].indexOf(activeStep) >= idx;
              const isActive = activeStep === step.id;

              return (
                <div 
                  key={step.id}
                  className={cn(
                    "flex items-center gap-3 transition-all duration-300",
                    isActive ? "text-accent opacity-100" : isCompleted ? "text-accent opacity-80" : "text-gray-600 opacity-50"
                  )}
                >
                  <div className={cn(
                    "w-2 h-2 rounded-full",
                    (isActive || isCompleted) ? "bg-currentColor shadow-[0_0_8px_currentColor]" : "bg-border"
                  )} />
                  <span className="text-xs font-semibold uppercase font-mono">{step.label}</span>
                </div>
              );
            })}
          </div>
        </nav>

        <div className="mt-auto">
          <div className="p-4 bg-panel border border-border border-dashed rounded-[2px] transition-all">
            <div className="text-[9px] uppercase text-text-dim mb-2 font-mono tracking-tighter">Current Session</div>
            <div className="text-[11px] text-accent truncate font-mono mb-4">
              {data.length > 0 ? `active_capture_${data.length}.raw` : "system_idle.null"}
            </div>
            <div className="space-y-2">
              {data.length === 0 ? (
                <button 
                  onClick={loadSampleData}
                  className="w-full border border-accent/20 text-accent font-bold py-2 rounded-[2px] uppercase text-[10px] cursor-pointer hover:bg-accent/5 transition-all font-mono"
                >
                  Load Demo Environment
                </button>
              ) : (
                <button 
                  disabled={data.length === 0}
                  onClick={runAnalysis}
                  className="w-full bg-accent text-bg font-bold py-2 rounded-[2px] uppercase text-[11px] cursor-pointer hover:brightness-110 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                  Execute Analysis
                </button>
              )}
              <div className="flex justify-between items-center px-1">
                <span className="text-[8px] text-gray-600 font-mono">SEC_CORE_v2</span>
                <span className="text-[8px] text-accent font-mono">READY</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <main className="lg:ml-[220px] p-6 lg:p-8">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <h2 className="text-2xl font-light tracking-tight mb-1">
              Analysis Workspace <span className="text-text-dim text-sm italic ml-2">/ SSVEP_REALTIME_CORE</span>
            </h2>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-accent shadow-[0_0_4px_#4ade80]" />
                <span className="text-[10px] font-mono text-text-dim uppercase">Status: Stable</span>
              </div>
              <div className="text-[10px] font-mono text-gray-600 uppercase border-l border-border pl-4">
                Latency: 12ms // Source: Local
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <input 
              type="file" 
              accept=".csv" 
              className="hidden" 
              ref={fileInputRef}
              onChange={handleFileUpload} 
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-1.5 bg-accent text-bg border border-accent rounded-[2px] text-[11px] uppercase font-bold hover:brightness-110 transition-colors flex items-center gap-2"
            >
              <Upload className="w-3 h-3" />
              Ingest CSV
            </button>
          </div>
        </header>

        {data.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center min-h-[60vh] border border-dashed border-border rounded-[4px] bg-panel/20">
            <div className="max-w-md w-full px-8 text-center">
              <div className="w-16 h-16 bg-accent-dim flex items-center justify-center rounded-full mx-auto mb-6">
                <Brain className="w-8 h-8 text-accent animate-pulse" />
              </div>
              <h3 className="text-xl font-light mb-2">Initialize Analysis Core</h3>
              <p className="text-xs text-text-dim mb-8 leading-relaxed font-mono uppercase tracking-tight">
                system_ready // awaiting_ingestion // source_null
              </p>
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-bg border border-border p-4 rounded-[2px] text-left hover:border-accent group transition-all"
                >
                  <Upload className="w-4 h-4 text-gray-600 group-hover:text-accent mb-2 transition-colors" />
                  <div className="text-[10px] uppercase font-bold font-mono text-text mb-1 tracking-tighter">Local Dataset</div>
                  <div className="text-[9px] text-gray-600 font-mono italic">Import .csv</div>
                </button>
                <button 
                  onClick={loadSampleData}
                  className="bg-bg border border-border p-4 rounded-[2px] text-left hover:border-accent group transition-all"
                >
                  <Activity className="w-4 h-4 text-gray-600 group-hover:text-accent mb-2 transition-colors" />
                  <div className="text-[10px] uppercase font-bold font-mono text-text mb-1 tracking-tighter">Synthetic Suite</div>
                  <div className="text-[9px] text-gray-600 font-mono italic">Demo Environment</div>
                </button>
              </div>
            </div>
            
            <div className="mt-16 w-full max-w-2xl px-8 flex flex-col items-center">
               <div className="text-[8px] font-mono text-gray-600 mb-4 tracking-[0.3em] uppercase">Security Core: Active // Encryption: Enabled</div>
               <div className="flex gap-1">
                 {[...Array(12)].map((_, i) => (
                   <motion.div 
                     key={i} 
                     className="w-4 h-1 bg-accent/20 rounded-full"
                     animate={{ opacity: [0.2, 1, 0.2] }}
                     transition={{ duration: 2, repeat: Infinity, delay: i * 0.1 }}
                   />
                 ))}
               </div>
            </div>
          </div>
        ) : (
          <>
            {summary && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard label="Trial Count" value={summary.count.toLocaleString()} info="TOTAL_N" />
            <StatCard label="Accuracy" value={`${round(summary.accuracy, 1)}%`} info="AVG_ACC" color="text-accent" />
            <StatCard label="Beta Power" value={`${round(summary.meanBeta, 2)}`} info="POWER_DB" color="text-accent" />
            <StatCard label="Mean RT" value={`${Math.round(summary.meanRT)}`} info="LATENCY_MS" color="text-orange-400" />
          </div>
        )}

        <AnimatePresence>
          {analyzed && results && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.99 }}
              animate={{ opacity: 1, scale: 1 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8"
            >
              <div className="bg-panel border border-border p-5 rounded-[4px] flex items-center gap-6">
                <div className="text-accent font-mono font-bold text-2xl border-r border-border pr-6">
                  r = {round(results.correlation.r, 2)}
                </div>
                <div>
                  <p className="text-[9px] uppercase text-text-dim font-mono mb-1">Statistical Correlation (RT/Beta)</p>
                  <p className="text-xs leading-snug text-gray-400 max-w-sm">
                    {getInterpretation(results.correlation.p, 'correlation found between beta-band power and response latency')}
                  </p>
                </div>
              </div>

              <div className="bg-panel border border-border p-5 rounded-[4px] flex items-center gap-6">
                <div className="text-pink-400 font-mono font-bold text-2xl border-r border-border pr-6">
                  p {results.ttest.p < 0.001 ? '< 0.001' : `= ${round(results.ttest.p, 3)}`}
                </div>
                <div>
                  <p className="text-[9px] uppercase text-text-dim font-mono mb-1">Difference Significance (Welch's t)</p>
                  <p className="text-xs leading-snug text-gray-400 max-w-sm">
                    {getInterpretation(results.ttest.p, 'difference measured between successful and missed neural states')}
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <ChartContainer title="Beta Power Distribution">
            {data.length > 0 ? (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={histogramData}>
                  <XAxis dataKey="bin" stroke="#484f58" fontSize={9} tickLine={false} axisLine={false} />
                  <YAxis hide stroke="#484f58" fontSize={9} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0b0e14', border: '1px solid #2d3748', borderRadius: '2px', fontSize: '10px', fontFamily: 'monospace' }}
                  />
                  <Bar dataKey="count" fill="#4ade80" opacity={0.6} radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <EmptyChart />}
          </ChartContainer>

          <ChartContainer title="Beta vs Response Latency">
            {data.length > 0 ? (
              <ResponsiveContainer width="100%" height={260}>
                <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: 0 }}>
                  <XAxis type="number" dataKey="beta_power_db" stroke="#484f58" fontSize={9} domain={['auto', 'auto']} tickLine={false} />
                  <YAxis type="number" dataKey="reaction_time_ms" stroke="#484f58" fontSize={9} domain={['auto', 'auto']} tickLine={false} />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} contentStyle={{ backgroundColor: '#0b0e14', border: '1px solid #2d3748', fontSize: '10px' }} />
                  <Scatter name="Trials" data={data} fill="#4ade80" fillOpacity={0.4} shape="square" />
                </ScatterChart>
              </ResponsiveContainer>
            ) : <EmptyChart />}
          </ChartContainer>

          <ChartContainer title="Successful vs Missed States">
            {analyzed && results ? (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={[
                  { name: 'Success', val: results.ttest.mean1 },
                  { name: 'Miss', val: results.ttest.mean2 }
                ]} margin={{ top: 20, right: 30, left: -20, bottom: 0 }}>
                  <XAxis dataKey="name" stroke="#484f58" fontSize={9} tickLine={false} />
                  <YAxis stroke="#484f58" fontSize={9} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#0b0e14', border: '1px solid #2d3748', fontSize: '10px' }} />
                  <Bar dataKey="val" radius={[2, 2, 0, 0]} barSize={40}>
                    <Cell fill="#4ade80" fillOpacity={0.5} stroke="#4ade80" />
                    <Cell fill="#f472b6" fillOpacity={0.5} stroke="#f472b6" />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : <EmptyChart />}
          </ChartContainer>

          <ChartContainer title="Fatigue Trendline (Block wise)">
            {analyzed && results ? (
              <ResponsiveContainer width="100%" height={260}>
                <LineChart data={results.fatigue}>
                  <XAxis dataKey="block" stroke="#484f58" fontSize={9} tickLine={false} />
                  <YAxis stroke="#484f58" fontSize={9} domain={['auto', 'auto']} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#0b0e14', border: '1px solid #2d3748', fontSize: '10px' }} />
                  <Line type="step" dataKey="beta" stroke="#4ade80" strokeWidth={1} dot={{ fill: '#4ade80', r: 3 }} activeDot={{ r: 5 }} />
                </LineChart>
              </ResponsiveContainer>
            ) : <EmptyChart />}
          </ChartContainer>

          <ChartContainer title="Spectral Density Plot">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={psdData}>
                <XAxis dataKey="freq" stroke="#484f58" fontSize={9} tickLine={false} />
                <YAxis hide stroke="#484f58" />
                <Tooltip contentStyle={{ backgroundColor: '#0b0e14', border: '1px solid #2d3748', fontSize: '10px' }} />
                <Area type="monotone" dataKey="psd" stroke="#f6ad55" fill="#f6ad55" fillOpacity={0.1} strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartContainer>

          <ChartContainer title="Oz Average Waveform">
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={erpData}>
                <XAxis dataKey="time" stroke="#484f58" fontSize={9} tickLine={false} />
                <YAxis hide stroke="#484f58" />
                <Tooltip contentStyle={{ backgroundColor: '#0b0e14', border: '1px solid #2d3748', fontSize: '10px' }} />
                <Legend iconType="rect" iconSize={8} wrapperStyle={{ fontSize: '9px', textTransform: 'uppercase', fontFamily: 'monospace' }} />
                <Line type="basis" dataKey="correct" stroke="#4ade80" strokeWidth={1.5} dot={false} name="Valid" />
                <Line type="basis" dataKey="missed" stroke="#f472b6" strokeWidth={1.5} dot={false} name="Miss" />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
            </div>
          </>
        )}
      </main>

      <AnimatePresence>
        {activeStep && activeStep !== 'Visualize' && (
          <div className="fixed inset-0 bg-bg/90 backdrop-blur-sm z-50 flex items-center justify-center">
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-panel border border-border p-8 rounded-[2px] max-w-sm w-full text-center shadow-[0_0_30px_rgba(0,0,0,0.5)]"
            >
              <div className="relative w-16 h-16 mx-auto mb-6">
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 border-2 border-accent/20 border-t-accent rounded-full"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Brain className="w-6 h-6 text-accent" />
                </div>
              </div>
              <h3 className="text-xs font-bold uppercase tracking-[0.2em] mb-1 text-accent">Processing Pipeline</h3>
              <p className="text-[10px] font-mono text-text-dim mb-6">STEP: <span className="text-text">{activeStep}</span></p>
              <div className="w-full bg-bg border border-border h-1 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-accent shadow-[0_0_8px_#4ade80]" 
                  initial={{ width: '0%' }}
                  animate={{ 
                    width: activeStep === 'Epoch' ? '25%' : 
                           activeStep === 'Clean' ? '50%' : 
                           activeStep === 'FFT' ? '75%' : 
                           activeStep === 'Analyze' ? '90%' : '100%' 
                  }}
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatCard({ label, value, info, color = "text-text" }: { label: string, value: string | number, info: string, color?: string }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-panel border border-border p-4 rounded-[4px] flex flex-col justify-between"
    >
      <div className="text-[9px] uppercase text-text-dim font-mono mb-2 tracking-widest">{label}</div>
      <div className="flex items-baseline justify-between">
        <h3 className={cn("text-2xl font-light font-sans tracking-tight", color)}>{value}</h3>
        <span className="text-[9px] font-mono text-gray-600 italic">[{info}]</span>
      </div>
    </motion.div>
  );
}

function ChartContainer({ title, children }: { title: string, children: React.ReactNode }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-panel border border-border p-5 rounded-[4px] flex flex-col group min-h-[360px]"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-[10px] font-bold text-text-dim uppercase tracking-widest font-mono">{title}</h3>
        <span className="text-[9px] text-gray-700 font-mono tracking-tighter">DATA_STREAM::V_ALIGNED</span>
      </div>
      <div className="flex-1 w-full overflow-hidden">
        {children}
      </div>
    </motion.div>
  );
}

function EmptyChart() {
  return (
    <div className="h-full min-h-[260px] flex flex-col items-center justify-center text-gray-800 border border-dashed border-border rounded-[2px] bg-bg/10 relative overflow-hidden group">
      <div className="absolute inset-0 flex flex-col justify-between p-4 opacity-5">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="h-[1px] w-full bg-accent" />
        ))}
      </div>
      <motion.div 
        animate={{ opacity: [0.1, 0.3, 0.1] }}
        transition={{ duration: 3, repeat: Infinity }}
        className="flex flex-col items-center"
      >
        <Activity className="w-8 h-8 mb-3 opacity-20 text-accent group-hover:opacity-40 transition-opacity" />
        <p className="text-[9px] font-mono uppercase tracking-[0.3em] opacity-40 text-accent">Pulse Standby // No Signal</p>
      </motion.div>
    </div>
  );
}
